#define SECRET_SSID "WestBoyer" 
#define SECRET_PASS "West@7559"

#define IFTTT_resource "/M5_Activate/json/with/key/FCd1B0Ebp2uwjPp1WBESB" 
#define IFTTT_server "maker.ifttt.com"
